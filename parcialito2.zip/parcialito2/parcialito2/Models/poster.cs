﻿namespace parcialito2.Models
{
    public class poster
    {
        public int idbuton { get; set; }
        public string percent {get; set;}
        public string src { get; set; }
        public string title { get; set; }
        public string srcicon { get; set; }

    }
}
