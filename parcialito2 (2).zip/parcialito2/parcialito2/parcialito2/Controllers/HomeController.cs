﻿using Microsoft.AspNetCore.Mvc;
using parcialito2.Models;
using System.Diagnostics;
using Microsoft.AspNetCore.Http;
using System.Dynamic;

namespace parcialito2.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public ActionResult Index()
        {
            //return View();

            dynamic mymodel = new ExpandoObject();
            mymodel.poster = RecuperarPoster();
            mymodel.topelement = Recuperartoppopular();

            return View(mymodel);
            
        }

        // GET: manipuladorvisual/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: manipuladorvisual/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: manipuladorvisual/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: manipuladorvisual/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: manipuladorvisual/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: manipuladorvisual/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }



        // POST: manipuladorvisual/Delete/5

        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }






        [NonAction]
        public List<topelement> Recuperartoppopular()
        {
            return new List<topelement>
            {
                new topelement
                {
                    title = "Mario bros",
                    srcicon = "https://www.w3schools.com/images/compatible_chrome.png",
                    percent="12%",
                    idbuton = 1

                },
                new topelement
                {
                    title = "Mario bros",
                    srcicon = "https://www.w3schools.com/images/compatible_chrome.png",
                    percent="12%",
                    idbuton = 2

                },
                new topelement
                {
                    title = "Mario bros",
                    srcicon = "https://www.w3schools.com/images/compatible_chrome.png",
                    percent="12%",
                    idbuton = 3

                },
                new topelement
                {
                    title = "Mario bros",
                    srcicon = "https://www.w3schools.com/images/compatible_chrome.png",
                    percent="12%",
                    idbuton = 4

                },
                new topelement
                {
                    title = "Mario bros",
                    srcicon = "https://www.w3schools.com/images/compatible_chrome.png",
                    percent="12%",
                    idbuton = 5

                },
                new topelement
                {
                    title = "Mario bros",
                    srcicon = "https://www.w3schools.com/images/compatible_chrome.png",
                    percent="12%",
                    idbuton = 6

                },
                new topelement
                {
                    title = "Mario bros",
                    srcicon = "https://www.w3schools.com/images/compatible_chrome.png",
                    percent="12%",
                    idbuton = 7

                },
                new topelement
                {
                    title = "Mario bros",
                    srcicon = "https://www.w3schools.com/images/compatible_chrome.png",
                    percent="12%",
                    idbuton = 8

                },
                new topelement
                {
                    title = "Mario bros",
                    srcicon = "https://www.w3schools.com/images/compatible_chrome.png",
                    percent="12%",
                    idbuton = 9

                },
                new topelement
                {
                    title = "Mario bros",
                    srcicon = "https://www.w3schools.com/images/compatible_chrome.png",
                    percent="12%",
                    idbuton = 10

                }
            };
        }
            

        [NonAction]
        public List<poster> RecuperarPoster()
        {
            return new List<poster>
            {
                new poster

                {

                    title = "Mario bros",
                    srcicon = "https://www.w3schools.com/images/compatible_chrome.png",
                    src = "https://resizing.flixster.com/3X1Rr-c7EyijQAqg6WnHIq7v31g=/206x305/v2/https://resizing.flixster.com/nQN8KYVFA4fD23Li3TCLwKYz8GA=/ems.cHJkLWVtcy1hc3NldHMvbW92aWVzL2JlYWVjZDdiLTMyYjMtNDgzNy1iN2M0LTgzYWZkODIzMmZmOS5qcGc=",
                    percent="12%",
                    idbuton = 1

                },

                new poster
                {

                    title = "bowset fucker",
                    srcicon = "https://www.w3schools.com/images/compatible_chrome.png",
                    src = "https://resizing.flixster.com/3X1Rr-c7EyijQAqg6WnHIq7v31g=/206x305/v2/https://resizing.flixster.com/nQN8KYVFA4fD23Li3TCLwKYz8GA=/ems.cHJkLWVtcy1hc3NldHMvbW92aWVzL2JlYWVjZDdiLTMyYjMtNDgzNy1iN2M0LTgzYWZkODIzMmZmOS5qcGc=",
                    percent="83%",
                    idbuton = 2

                },
                new poster

                {

                    title = "xorraf",
                    srcicon = "https://www.w3schools.com/images/compatible_chrome.png",
                    src = "https://resizing.flixster.com/3X1Rr-c7EyijQAqg6WnHIq7v31g=/206x305/v2/https://resizing.flixster.com/nQN8KYVFA4fD23Li3TCLwKYz8GA=/ems.cHJkLWVtcy1hc3NldHMvbW92aWVzL2JlYWVjZDdiLTMyYjMtNDgzNy1iN2M0LTgzYWZkODIzMmZmOS5qcGc=",
                    percent="42%",
                    idbuton = 3

                },
                new poster

                {

                    title = "brosi",
                    srcicon = "https://www.w3schools.com/images/compatible_chrome.png",
                    src = "https://resizing.flixster.com/3X1Rr-c7EyijQAqg6WnHIq7v31g=/206x305/v2/https://resizing.flixster.com/nQN8KYVFA4fD23Li3TCLwKYz8GA=/ems.cHJkLWVtcy1hc3NldHMvbW92aWVzL2JlYWVjZDdiLTMyYjMtNDgzNy1iN2M0LTgzYWZkODIzMmZmOS5qcGc=",
                    percent="25%",
                    idbuton = 4

                },
                new poster

                {

                    title = "Mario hof",
                    srcicon = "https://www.w3schools.com/images/compatible_chrome.png",
                    src = "https://resizing.flixster.com/3X1Rr-c7EyijQAqg6WnHIq7v31g=/206x305/v2/https://resizing.flixster.com/nQN8KYVFA4fD23Li3TCLwKYz8GA=/ems.cHJkLWVtcy1hc3NldHMvbW92aWVzL2JlYWVjZDdiLTMyYjMtNDgzNy1iN2M0LTgzYWZkODIzMmZmOS5qcGc=",
                    percent="78%",
                    idbuton = 5

                },
                new poster

                {

                    title = "air",
                    srcicon = "https://www.w3schools.com/images/compatible_chrome.png",
                    src = "https://resizing.flixster.com/3X1Rr-c7EyijQAqg6WnHIq7v31g=/206x305/v2/https://resizing.flixster.com/nQN8KYVFA4fD23Li3TCLwKYz8GA=/ems.cHJkLWVtcy1hc3NldHMvbW92aWVzL2JlYWVjZDdiLTMyYjMtNDgzNy1iN2M0LTgzYWZkODIzMmZmOS5qcGc=",
                    percent="54%",
                    idbuton = 6

                },
            };
        }






    }
}





