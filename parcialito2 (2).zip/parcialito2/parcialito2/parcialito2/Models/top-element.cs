﻿namespace parcialito2.Models
{
    public class topelement
    {
        public int idbuton { get; set; }
        public string percent { get; set; }
        public string title { get; set; }
        public string srcicon { get; set; }

    }
}